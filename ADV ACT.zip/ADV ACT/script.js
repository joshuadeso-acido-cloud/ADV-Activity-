
async function fetchUsers() {
    try {
        
        const response = await fetch('https://jsonplaceholder.typicode.com/users');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const users = await response.json();
        return users;
    } catch (error) {
        console.error('Error fetching users:', error);
        throw error; 
    }
}

function displayUsers(users) {
    const usersContainer = document.getElementById('usersContainer');
    const errorDiv = document.getElementById('error');
    
    errorDiv.style.display = 'none';
    errorDiv.innerHTML = '';
    
    if (!users || users.length === 0) {
        usersContainer.innerHTML = '<div class="no-users">No users found</div>';
        return;
    }
    
    const usersHTML = users.map(user => {
        const city = user.address?.city || 'City not available';
        
        return `
            <div class="user-card">
                <div class="user-name">👤 ${user.name}</div>
                <div class="user-detail">
                    <strong>Email:</strong> 
                    <a href="mailto:${user.email}" class="user-email">${user.email}</a>
                </div>
                <div class="user-detail">
                    <strong>City:</strong> ${city}
                </div>
            </div>
        `;
    }).join('');
    
    usersContainer.innerHTML = usersHTML;
}

function showLoading(show) {
    const loadingDiv = document.getElementById('loading');
    const fetchBtn = document.querySelector('.fetch-btn');
    
    loadingDiv.style.display = show ? 'block' : 'none';
    fetchBtn.disabled = show;
}

function showError(message) {
    const errorDiv = document.getElementById('error');
    const usersContainer = document.getElementById('usersContainer');
    
    errorDiv.style.display = 'block';
    errorDiv.innerHTML = `❌ ${message}`;
    
    usersContainer.innerHTML = '<div class="no-users">Unable to load users</div>';
}

async function fetchAndDisplayUsers() {
    try {
        showLoading(true);
        
        document.getElementById('error').style.display = 'none';
        
        const users = await fetchUsers();
        
        displayUsers(users);
        
    } catch (error) {
        showError('Failed to fetch users. Please try again later.');
    } finally {
        showLoading(false);
    }
}

async function initializeApp() {
   
}

document.addEventListener('DOMContentLoaded', initializeApp);

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { fetchUsers, displayUsers, fetchAndDisplayUsers };
}